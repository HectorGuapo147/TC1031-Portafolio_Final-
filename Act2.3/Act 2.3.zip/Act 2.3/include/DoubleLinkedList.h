// Clase Double Linked List
// Por: Noemi Guerra A00826944, Izac Salazar A01197392 y Hector Guapo A01197463
// Sabado 10 de octubre del 2020

#include "Node.h"

using namespace std;

class DoubleLinkedList{
    public:
        DoubleLinkedList();
        void addFirst(Info data);
        void addLast(Info data);
        int deleteAll();
        int getSize();
        bool isEmpty();
        void ordenaBurbuja();
        void muestraIps(long ini, long fin);
        void print(string nomArch);
        ~DoubleLinkedList();
    private:
        Node *head;
        Node *tail;
        int size;
};

// Constructor
// Complejidad: O(1)
DoubleLinkedList::DoubleLinkedList(){
    head = nullptr;
    tail = nullptr;
    size = 0;
}

// A�ade datos al principio
// Complejidad O(1)
void DoubleLinkedList::addFirst(Info data){
    if(size==0){
      head=tail=new Node(data);
    }
    else{
      head->setPrev(new Node(data,head,nullptr));
      head = head->getPrev();
    }
    size++;
}

// A�ade datos al final
// Complejidad 0(n)
void DoubleLinkedList::addLast(Info data){
    if(head == nullptr){
        addFirst(data);
    }
    else{
        tail->setNext(new Node(data,nullptr,tail));
        tail = tail->getNext();
        size++;
    }

}

// Elimina todos los elementos de la estructura de datos
// Complejidad: O(n)
int DoubleLinkedList::deleteAll(){
    Node *curr = head;
    while(head != nullptr){
        head = head->getNext(); // Avanza uno a head
        delete curr; // Elimina curr
        curr = head;
    }
    int sizeAux = size;
    size = 0;
    return sizeAux;
}

// Indica el tama�o
// Complejidad: O(1)
int DoubleLinkedList::getSize(){
    return size;
}

// Indica si la estructura esta vacia
//Complejidad: O(1)
bool DoubleLinkedList::isEmpty(){
    return size == 0;
}

// Ordena los datos por el metodo de burbuja
// Complejidad: O(n^2)
void DoubleLinkedList::ordenaBurbuja(){
  Node *curr;
  Info temp;
  long key1,key2;
  bool interruptor = true;

    for (int pas=0; pas<size-1 && interruptor; pas++){
      curr = head;
      interruptor = false;
      //cout << pas << endl;
      for (int j=0; j<size-1-pas; j++){
        Node *currAct = curr;
        Node *currNext = currAct->getNext();
        key1 = currAct->getData().key;
        key2 = currNext->getData().key;
        if (key2 < key1){
          temp = currNext->getData();
          currNext->setData(currAct->getData());
          currAct->setData(temp);
          interruptor = true;
      }
      curr = curr->getNext();
    }
  }
}

// Muestra las ips en el rango establecido por el usuario
// Complejidad: O(n)
void DoubleLinkedList::muestraIps(long ini, long fin){
    Node *curr = head;
    cout << "Resultados de la busqueda" << endl;
    if(head==nullptr)
      cout << "Esta vac�o" << endl;
    else{
      while(curr!=nullptr){
          if(curr->getData().key >= ini && curr->getData().key <= fin){
              cout << curr->getData().mes << " " << curr->getData().dia << " " << curr-> getData().hora << " " << " "<< curr->getData().dirIp << " " << curr->getData().razon<< endl;
          }
          curr = curr->getNext();
      }
    }
}

// Imprime todos los datos adquiridos
// Complejidad: O(n)
void DoubleLinkedList::print(string nomArch){
    ofstream archMuestra(nomArch);
    Node *curr = head;
    archMuestra << "Contenido ordenado de la DoubleLinkedList" << endl;
    while(curr!= nullptr){
        archMuestra << curr->getData().mes << " " << curr->getData().dia << " " << curr-> getData().hora << " " << " "<< curr->getData().dirIp << " " << curr->getData().razon<< endl;
        curr = curr->getNext();
    }
    archMuestra.close();
}

// Destructor
// Complejidad O(n)
DoubleLinkedList::~DoubleLinkedList(){
    deleteAll();
}
