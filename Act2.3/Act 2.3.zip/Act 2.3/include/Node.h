// Clase Nodo
// Por: Noemi Guerra A00826944, Izac Salazar A01197392 y Hector Guapo A01197463
// Sabado 10 de octubre del 2020

using namespace std;

struct Info{
    long key;
    string mes;
    int dia;
    string hora;
    string dirIp;
    string razon;
};

class Node{
    public:
        Node(Info data);
        Node(Info data, Node *next, Node *prev);
        Info getData();
        Node* getNext();
        Node* getPrev();
        void setData(Info data);
        void setNext(Node *next);
        void setPrev(Node *prev);
    private:
        Info data;
        Node *next;
        Node *prev;
};

// Constructor con un parametro
// Complejidad: O(1)
Node::Node(Info data){
    this->data = data;
    this->next = nullptr;
    this->prev = nullptr;
}

// Constructor de tres parametros
// Complejidad: O(1)
Node::Node(Info data, Node *next, Node *prev){
    this->data = data;
    this->next = next;
    this->prev = prev;
}

// Obtener la info
// Complejidad: O(1)
Info Node:: getData(){
    return data;
}

// Obtener el siguiente nodo
// Complejidad: O(1)
Node* Node:: getNext(){
    return next;
}

// Obtener el nodo previo
// Complejidad: O(1)
Node* Node:: getPrev(){
    return prev;
}

// Asignar un dato
// Complejidad: O(1)
void Node::setData(Info data){
    this->data = data;
}

 // Asignar algo algo siguiente
 // Compljidad: O(1)
void Node::setNext(Node *next){
    this->next = next;
}

// Asignar algo al previo
// Complejidad: O(1)
void Node::setPrev(Node *prev){
    this->prev = prev;
}
