// Programa de busqueda y ordenamiento de una bitacora a partir de una estructura de datos de DoubleLinkedList
// Por: Noemi Guerra A00826944, Izac Salazar A01197392 y Hector Guapo A01197463
// Sabado 10 de octubre del 2020

#include <iostream>
#include <string>
#include <fstream>
#include "DoubleLinkedList.h"

using namespace std;

// Convierte la ip a key
// Complejidad: O(n)
long ipToLong(string ip){
	int idx = 0;
	long datoFinal= 0, dato = 0;
	while (idx < ip.size()){
		if (ip[idx]!= '.' && ip[idx]!=':'){
			dato = dato*10 + ip[idx]-'0';
		}
		else{
			datoFinal = datoFinal*1000 + dato;
			dato = 0;
		}
		idx++;
	}
	datoFinal = datoFinal*10000 + dato;
	return datoFinal;
}

// Carga los datos del archivo bitacora
// Complejidad: O(n)
void cargaDatosBitacora(DoubleLinkedList &lista, Info &datos, int &cant){
    string mes, hora, dirIp, razon, renglon;
    int dia;

    ifstream archivo;
    archivo.open("bitacora.txt");

    while(archivo>>mes>>dia>>hora>>dirIp){
        getline(archivo, razon);
        datos.mes = mes;
        datos.dia = dia;
        datos.hora = hora;
        datos.dirIp = dirIp;
        datos.razon = razon;
        datos.key = ipToLong(datos.dirIp);
        lista.addLast(datos);
        cant++;
    }

    archivo.close();
}

int main() {
    DoubleLinkedList lista;
    Info datos;
    string ipIni, ipFin, nomArch, ans;
    int cantDatos = 0;

    cout << "Bienvenido" << endl;
    cout << "Espere un momento a que se ordenen los datos" << endl;
    cout << endl;

    cargaDatosBitacora(lista, datos,cantDatos);
    lista.ordenaBurbuja();

    do{
    cout << "Ip inicial: " << endl;
    cin >> ipIni;
    cout << "Ip final: " << endl;
    cin >> ipFin;

    long keyIni = ipToLong(ipIni), keyFin = ipToLong(ipFin);

    lista.muestraIps(keyIni, keyFin);
    cout << endl;

    cout << "Deseas hacer otra busqueda? si/no " << endl;
    cin >> ans;
    }while (ans != "no");
    cout << endl;

    cout << "Ingrese el nombre desdeado para el archivo de salida con los datos ordenados: " << endl;
    cin >> nomArch;
    lista.print(nomArch);

}
