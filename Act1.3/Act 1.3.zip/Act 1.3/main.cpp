// Programa para ordenar un archivo de bit�cora por fechas a trav�s del m�todo de inserci�n y buscar fechas con el m�todo binario
// Por: Noemi Guerra A00826944, Izac Salazar A01197392 y H�ctor Guapo A01197463
// Viernes 11 de Septiembre del 2020

#include <iostream>
#include <vector>
#include <string>
#include <fstream>

using namespace std;

// Estructura para crear un vector capaz de contener los 5 atributos de la bit�cora m�s el key
struct linea{
    int key;
    string mes;
    int dia;
    string hora;
    string dirIp;
    string razon;
};

// Funci�n para cargar los datos de la bit�cora a un vector
// Complejidad: lineal O(n)
void cargaDatosBitacora(vector<linea> &vecR, int &cantRegistros){
    string mes, hora, dirIp, razon;
    int dia;

    ifstream archivo;
    archivo.open("bitacora.txt");
    cantRegistros = 0;

    while(archivo>>mes>>dia>>hora>>dirIp){
        getline(archivo, razon);
        vecR.push_back(linea());
        vecR[cantRegistros].mes = mes;
        vecR[cantRegistros].dia = dia;
        vecR[cantRegistros].hora = hora;
        vecR[cantRegistros].dirIp = dirIp;
        vecR[cantRegistros].razon = razon;
        cantRegistros++;
    }
    archivo.close();
}

// Funci�n para generar el key dentro del vector (la fecha como n�mero)
// Complejidad: lineal O(n)
void generaKey(vector<linea> &vecK){
    string meses[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    for(int cantV=0; cantV<vecK.size();cantV++){
        for(int cantM = 0; cantM < 12; cantM++){
            if(meses[cantM] != vecK[cantV].mes)
                vecK[cantV].key += 100;
            else{
                vecK[cantV].key += 100 + vecK[cantV].dia;
                break;
            }
        }
    }
}

// Funci�n de ordenamiento, ordena los datos del vector mediante el key
// Complejidad: cuadr�tica O(n^2)
int ordenaInsercion(vector<linea> &vec){
    int tempK, tam = vec.size(), j, cant = 0;
    int tempD;
    string tempM, tempIp, tempR;
    for(int i = 0; i<tam; ++i){
        j = i;
        tempK = vec[i].key;
        tempM = vec[j].mes;
        tempD = vec[j].dia;
        tempIp = vec[j].dirIp;
        tempR = vec[j].razon;
        while(j>0 && tempK<vec[j-1].key){
            cant++;
            vec[j].key = vec[j-1].key;
            vec[j].mes = vec[j-1].mes;
            vec[j].dia = vec[j-1].dia;
            vec[j].dirIp = vec[j-1].dirIp;
            vec[j].razon = vec[j-1].razon;
            j--;
        }
        if(j != 0)
            cant++;
        vec[j].key = tempK;
        vec[j].mes = tempM;
        vec[j].dia = tempD;
        vec[j].dirIp = tempIp;
        vec[j].razon = tempR;
    }
    return cant;
}

// Funci�n para convertir la fecha de entrada en key
// Complejidad: lineal O(n)
int generaUnKey(string m, int d){
    int key = 0;
    string meses[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    for(int cantM = 0; cantM < 12; cantM++){
       if(meses[cantM] != m)
            key += 100;
       if(meses[cantM] == m){
            key += 100 + d;
            return key;
       }
    }
}


// Funci�n de busqueda binaria para posici�n inicial
// Complejidad: lineal O(n)
int busqBinariaIni(vector<linea> &v, int &dato, int &cantBB){
    cantBB = 0;
    int fin = v.size()-1, inicio = 0, mitad;
    while(inicio <= fin){
        mitad = (inicio+fin)/2;
        cantBB++;
        if((v[mitad].key) == dato){
            while(v[mitad-1].key==v[mitad].key)
              mitad = mitad-1;
            return mitad;
        }
        if((v[mitad].key) > dato)
            fin = mitad-1;
        else
            inicio = mitad+1;
    }
    return -1;
}

// Funci�n de busqueda binaria para posici�n final
// Complejidad: lineal O(n)
int busqBinariaFin(vector<linea> &v, int &dato, int &cantBB){
    cantBB = 0;
    int fin = v.size()-1, inicio = 0, mitad;
    while(inicio <= fin){
        mitad = (inicio+fin)/2;
        cantBB++;
        if((v[mitad].key) == dato){
            while(v[mitad+1].key==v[mitad].key)
              mitad = mitad+1;
            return mitad;
        }
        if((v[mitad].key) > dato)
            fin = mitad-1;
        else
            inicio = mitad+1;
    }
    return -1;
}

// Funci�n para mostrar los resultados de la busqueda y ordenamiento en otro archivo
// Complejidad: lineal O(n)
void muestraDatos(vector<linea> v, int ini, int fin){
    for(int i=ini; i<=fin; i++)
        cout << v[i].mes << " " << v[i].dia << " " << v[i].hora << " " << v[i].dirIp << " " << v[i].razon << endl;
    cout << endl;
}

// Funci�n para mostrar todos los datos ordenados de la bit�cora en otro archivo
// Complejidad: lineal O(n)
void salidaDatosOrdenados(vector<linea> v, int cant, string nomArch){
  ofstream archMuestra(nomArch);
  for(int i=0; i<cant; i++){
        archMuestra << v[i].mes << " " << v[i].dia << " " << v[i].hora << " " << v[i].dirIp << " " << v[i].razon << endl;
    }
  archMuestra.close();
}


int main() {
    vector<linea> vecR;
    int cantRegistros, busqDiaIni, busqDiaFin, cantBB;
    int rangoKeyIni, rangoKeyFin, posIni, posFin;

    string busqMesIni, busqMesFin, opcion, archSal;
    cargaDatosBitacora(vecR,cantRegistros);
    generaKey(vecR);
    ordenaInsercion(vecR);

    cout << "Sistema de busqueda de registros de bit�cora" << endl;

    do {
        cout << "Mes inicial: ";
        cin >> busqMesIni;
        cout << "Dia inicial: ";
        cin >> busqDiaIni;
        cout << "Mes final: ";
        cin >> busqMesFin;
        cout << "Dia final: ";
        cin >> busqDiaFin;
        cout << endl;

        generaUnKey(busqMesIni, busqDiaIni);
        generaUnKey(busqMesFin, busqDiaFin);

        rangoKeyIni = generaUnKey(busqMesIni, busqDiaIni);
        rangoKeyFin = generaUnKey(busqMesFin, busqDiaFin);

        if(rangoKeyIni >= vecR[0].key && rangoKeyFin <= vecR[vecR.size()-1].key){
            posIni = busqBinariaIni(vecR,rangoKeyIni,cantBB);
            posFin = busqBinariaFin(vecR,rangoKeyFin,cantBB);

            muestraDatos(vecR, posIni, posFin);
        }
        else{
            cout << " Una o ambas fechas no se encuentra en el registro" << endl;
            cout << endl;
        }
        cout << "Desea seguir? Ingrese si o no: ";
        cin >> opcion;
        } while(opcion != "no");

        cout << "Ingrese el nombre del archivo de salida con los datos ordenados: ";
        cin >> archSal;

        salidaDatosOrdenados(vecR, cantRegistros, archSal);

        cout << "Gracias" << endl;
}
