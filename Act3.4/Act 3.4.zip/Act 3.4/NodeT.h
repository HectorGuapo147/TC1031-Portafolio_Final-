// ADT de NodeT
// Equipo 1: Noemi Carolina Guerra Montiel A00826944, Izac Salazar A01197392 y Hector Guapo A01197463
// Domingo 25 de octubre del 2020

class NodeT{
public:
    NodeT(long ip, int cantAcc);
    NodeT(long ip, int cantAcc, NodeT *left, NodeT *right);
    int getAccesos();
    void setAccesos(int cantAcc);
    long getIp();
    void setIp(long ip);
    NodeT* getLeft();
    void setLeft(NodeT *left);
    NodeT* getRight();
    void setRight(NodeT *right);
private:
    int cantAcc;
    long ip;
    NodeT *left;
    NodeT *right;
};

NodeT::NodeT(long ip, int cantAcc){
    this->cantAcc = cantAcc;
    this->ip = ip;
    this->left = nullptr;
    this->right = nullptr;
}

NodeT::NodeT(long ip, int cantAcc, NodeT *left, NodeT *right){
    this->cantAcc = cantAcc;
    this->ip = ip;
    this->left = left;
    this->right = right;
}

int NodeT::getAccesos(){
    return cantAcc;
}

void NodeT::setAccesos(int cantAcc){
    this->cantAcc = cantAcc;
}

long NodeT::getIp(){
    return ip;
}

void NodeT::setIp(long ip){
    this->ip = ip;
}

NodeT* NodeT::getLeft(){
    return left;
}

void NodeT::setLeft(NodeT *left){
    this->left = left;
}

NodeT* NodeT::getRight(){
    return right;
}

void NodeT::setRight(NodeT *right){
    this->right = right;
}
