// Programa para almacenar los datos de una bitacora en una lista de adyacencia, determinar los nodos con mas fan-out y la direccion ip con el botmaster
//  Equipo 1: Noemi Carolina Guerra Montiel A00826944, Izac Salazar A01197392 y Hector Guapo A01197463
// Viernes 20 de noviembre del 2020

#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <iterator>

using namespace std;

// Función para quitar el puerto de la direccion ip
// Complejidad: O(n)
string quitarPuerto(string ip){
    int idx = 0;
    string ipSinPuerto;
    while (idx < ip.size() && ip[idx]!=':')
        ipSinPuerto += ip[idx++];
    return ipSinPuerto;
}

// Función para crear el mapa del grafo y la lista de adyacencia
// Complejidad: O(V+E)
void loadGraph(unordered_map<string, pair<int, int>> &nodos_ips, int &max){
    string mes, nodo, ip, hora, dirIpSal, dirIpEnt, razon;
    int dia, numNodoEnt, numNodoSal, n, m;

    ifstream archivo;
    archivo.open("bitacoraACT4_3(B).txt");

    archivo >> n >> m;

    vector<vector<int>> listAdj(n);

    for(int i = 0; i < n; i++){
        archivo >> nodo;
        pair<int, int> parejaNodos;
        parejaNodos.first = i;
        parejaNodos.second = 0;
        nodos_ips[nodo] = parejaNodos;
    }

    for(int i = 0; i < m; i++){
        archivo>>mes>>dia>>hora>>dirIpSal>>dirIpEnt;
        getline(archivo, razon);
        dirIpSal = quitarPuerto(dirIpSal);
        dirIpEnt = quitarPuerto(dirIpEnt);
        
        numNodoSal = nodos_ips[dirIpSal].first;
        numNodoEnt = nodos_ips[dirIpEnt].first;
        nodos_ips[dirIpSal].second++;
        
        if (nodos_ips[dirIpSal].second > max)
            max = nodos_ips[dirIpSal].second;

        listAdj[numNodoSal].push_back(numNodoEnt);
    }
    archivo.close();
}

// Función para imprimir la direccion ip con el botmaster
// Complejidad: O(n)
void printBotmaster(unordered_map<string, pair<int, int>> nodos_ips, int max){
    unordered_map<string, pair<int, int>>::iterator it;
    for(it = nodos_ips.begin(); it != nodos_ips.end(); ++it){
        if ((it->second).second == max)
            cout << it->first << " " << max << endl;
    }
}

int main() {
    unordered_map<string, pair<int, int>> nodos_ips;
    int max = 0;

    loadGraph(nodos_ips, max);
    printBotmaster(nodos_ips, max);

    return 0;
}
